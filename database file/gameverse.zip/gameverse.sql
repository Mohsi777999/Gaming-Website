-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2024 at 08:01 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gameverse`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(255) NOT NULL,
  `admin_username` varchar(255) DEFAULT NULL,
  `admin_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `game_id` int(255) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `game_img` varchar(255) DEFAULT NULL,
  `game_genre` varchar(50) NOT NULL,
  `game_price` varchar(20) NOT NULL,
  `game_para` longtext NOT NULL,
  `game_min_require` text NOT NULL,
  `game_max_require` text NOT NULL,
  `downloads` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`game_id`, `game_name`, `game_img`, `game_genre`, `game_price`, `game_para`, `game_min_require`, `game_max_require`, `downloads`) VALUES
(76, 'Batman Arkham Asylum', 'img/batman.jpg', 'Action', 'Free', 'Batman: Arkham Asylum is a 2009 action-adventure game developed by Rocksteady Studios and published by Eidos Interactive in conjunction with Warner Bros. Interactive Entertainment. Based on the DC Comics superhero Batman and written by veteran Batman writer Paul Dini, Arkham Asylum was inspired by the long-running comic book mythos. In the game\'s main storyline, Batman battles his archenemy, the Joker, who instigates an elaborate plot to seize control of Arkham Asylum, trap Batman inside with many of his incarcerated foes, and threaten Gotham City with hidden bombs.', 'Minimum Requirements:  Operating System: Windows XP or Vista (Service Pack 1 recommended) Processor: Intel Pentium 4 3.0 GHz or AMD Athlon 64 3500+ Memory: 1 GB RAM (XP) or 2 GB RAM (Vista) Graphics Card: Nvidia 6600 or ATI Radeon X1300 with 128 MB VRAM (minimum of DirectX 9.0c support) Hard Drive Space: 9 GB free space With these specs, you should be able to run the game at lower graphical settings.', 'Recommended Requirements:  Operating System: Windows XP or Vista (Service Pack 1 recommended) Processor: Core 2 Duo E6600 (2.4 GHz) or AMD Athlon 64 X2 4600+ Memory: 2 GB RAM (XP) or 3 GB RAM (Vista) Graphics Card: Nvidia GeForce 7900 GT or better with 512 MB VRAM (minimum of DirectX 9.0c support) Hard Drive Space: 9 GB free space If you want to experience the game with smoother gameplay and higher quality visuals, these recommended specs are ideal.', 24),
(77, 'PUBG Battle Grounds', 'img/pubg.jpg', 'Battle Royale', 'Free', 'PUBG: Battlegrounds (previously known as PlayerUnknown\'s Battlegrounds) is a battle royale game developed by PUBG Studios and published by Krafton. The game, which was inspired by the Japanese film Battle Royale (2000), is based on previous mods created by Brendan \"PlayerUnknown\" Greene for other games, and expanded into a standalone game under Greene\'s creative direction. It is the first game in the PUBG Universe series.  The game is played from either a third-person or first-person perspective. In the game, up to one hundred players parachute onto an island where they scavenge for weapons and equipment to kill other players while avoiding getting killed themselves.', 'Minimum Requirements:  Operating System: Windows 7, 8.1, or 10 (64-bit only) Processor: Intel Core i5-4430 or AMD FX-6300 Memory: 8 GB RAM Graphics Card: Nvidia GeForce GTX 960 2GB or AMD Radeon R7 370 2GB DirectX: Version 11 Storage: 30 GB available space With these minimum specs, you should be able to run PUBG at lower graphical settings and potentially experience lower frame rates or performance issues.', 'Recommended Requirements:  Operating System: Windows 10 (64-bit only) Processor: Intel Core i5-6600K or AMD Ryzen 5 1600 Memory: 16 GB RAM Graphics Card: Nvidia GeForce GTX 1060 3GB or AMD Radeon RX 580 4GB DirectX: Version 11 Storage: 30 GB available space (note: some sources recommend 50 GB for additional content) These recommended specs will allow you to run PUBG at higher graphical settings with smoother gameplay and better overall performance.', 1),
(78, 'Call Of Duty Ghosts', 'img/cod ghost.jpg', 'Firing', '0', 'Call of Duty: Ghosts is a 2013 first-person shooter video game developed by Infinity Ward and published by Activision. It is the tenth major installment in the Call of Duty series and the sixth developed by Infinity Ward. It was released for PlayStation 3, Wii U, Windows, and Xbox 360, on November 5, 2013. The game was released with the launch of the PlayStation 4 and Xbox One.  The game acts as a standalone installment in the wider Call of Duty franchise in lieu of the World War II, Black Ops and Modern Warfare series that preceded it.', 'Minimum Requirements:  Operating System: Windows 7 64-Bit / Windows 8 64-Bit (Note: Windows 7 and 8 are no longer supported by Microsoft as of January 2023) Processor: Intel Core 2 Duo E8200 2.66 GHz / AMD Phenom X3 8750 2.4 GHz or better Memory: 6 GB RAM Graphics Card: NVIDIA GeForce GTS 450 / ATI Radeon HD 5870 or better DirectX: DirectX 11 Sound Card: Yes Hard Drive Space: 40 GB', 'Recommended Requirements:  Operating System: Windows 10 64-Bit (Latest version recommended) Processor: Intel Core i5-2500 @ 3.3 GHz / AMD FX-8350 @ 4.0 GHz or better Memory: 8 GB RAM Graphics Card: NVIDIA GeForce GTX 660 / ATI Radeon HD 7950 or better DirectX: DirectX 11 Sound Card: Yes Hard Drive Space: 40 GB', 1),
(79, 'GTA San Andreas', 'img/san.jpg', 'Open World', '0', 'Grand Theft Auto: San Andreas is a 2004 action-adventure game developed by Rockstar North and published by Rockstar Games. It is the seventh title in the Grand Theft Auto series, following 2002\'s Grand Theft Auto: Vice City. Set within the fictional state of San Andreas, the game follows Carl \"CJ\" Johnson, who returns home after his mother\'s murder and finds his old gang has lost much of their territory. Over the course of the game, he attempts to re-establish the gang, clashes with corrupt authorities and powerful criminals, and gradually unravels the truth behind his mother\'s murder.', 'Minimum Requirements:  Operating System: Microsoft Windows 2000 or Windows XP Processor: 1 GHz Pentium III or AMD Athlon processor Memory: 256 MB of RAM Graphics Card: 64 MB video card with DirectX 8.1 compatibility (e.g., NVIDIA GeForce 3 or better) Hard Drive Space: 3.6 GB of free space (minimal install) Sound Card: DirectX 9 compatible sound card DVD-ROM Drive: 8x speed DVD-ROM drive', 'Recommended Requirements:  Operating System: Microsoft Windows 2000 or Windows XP Processor: 2 GHz Pentium 4 or AMD Athlon XP processor Memory: 384 MB of RAM (the more, the better!) Graphics Card: 128 MB video card with DirectX 9.0c compatibility (e.g., NVIDIA GeForce 6 series recommended) Hard Drive Space: 4.7 GB of free space (full install) Sound Card: DirectX 9 compatible sound card DVD-ROM Drive: 16x speed DVD-ROM drive (speed not tested)', 1),
(80, 'Riders Republic', 'img/riders.jpg', 'Firing', '1500', 'The four main activities available in the game include mountain biking, skiing, snowboarding and wingsuit flying. Ubisoft described the game as a \"massively multiplayer sports game\", as up to 64 players can compete against each other in Mass Races competitions.[2] The PS4 and Xbox One versions only support about 20 players.[3] In addition, players can also play a 6v6 competitive multiplayer mode named \"Tricks Battle Arena\". In this mode, each team competes in an arena and needs to perform as many tricks as possible in order to score Trick points. The team with the highest score is the winner.', 'Minimum Requirements:  Operating System: Windows 10 (64-bit versions) Processor: Intel Core i5-4460 or AMD Ryzen 5 1400 Memory: 8 GB RAM (dual channel) Graphics Card: GeForce GTX 970 (4 GB) or AMD RX 470 (4 GB) DirectX: DirectX 12 Storage: 20 GB available space With these minimum specs, you should be able to run the game at lower graphical settings. Expect potentially lower frame rates and reduced visual quality.', 'Recommended Requirements:  Operating System: Windows 10 (64-bit versions) Processor: Intel Core i7-4790 or AMD Ryzen 5 1600 Memory: 8 GB RAM (dual channel) Graphics Card: GeForce GTX 1060 (6 GB) or AMD RX 570 (8 GB) DirectX: DirectX 12 Storage: 20 GB available space The recommended specs will allow you to enjoy Riders Republic at higher graphical settings with smoother gameplay and better visuals. For an optimal experience, these are the ideal specifications to target.', 1),
(81, 'Assassin Creed Mirage', 'img/assa.jpg', 'Action', '3000', 'Assassin\'s Creed Mirage is a 2023 action-adventure game developed by Ubisoft Bordeaux and published by Ubisoft. The game is the thirteenth major installment in the Assassin\'s Creed series and the successor to 2020\'s Assassin\'s Creed Valhalla. While its historical timeframe precedes that of Valhalla, its modern-day framing story succeeds Valhalla\'s own. Set in 9th-century Baghdad during the Islamic Golden Age—in particular during the Anarchy at Samarra—the story follows Basim Ibn Ishaq (a character first introduced in Valhalla), a street thief who joins the Hidden Ones to fight for peace and liberty, against the Order of the Ancients,[b] who desire peace through control. The main narrative focuses on Basim\'s internal struggle between his duties as a Hidden One and his desire to uncover his mysterious past.', 'Minimum Requirements (Estimated):  Operating System: Windows 10 64-bit (latest update) Processor: AMD Ryzen 3 3100 (or equivalent Intel Core i5) Memory: 8 GB RAM Graphics Card: Nvidia GeForce GTX 1060 6GB (or AMD Radeon RX 570 4GB) Hard Drive Space: 40 GB available space (SSD recommended) DirectX: DirectX 12', 'Recommended Requirements (Estimated):  Operating System: Windows 10/11 64-bit (latest update) Processor: AMD Ryzen 5 5600X (or equivalent Intel Core i7) Memory: 16 GB RAM Graphics Card: Nvidia GeForce RTX 2060 6GB (or AMD Radeon RX 5600 XT 6GB) Hard Drive Space: 40 GB available space (SSD highly recommended) DirectX: DirectX 12', NULL),
(82, 'FIFA 23', 'img/fifa.jpg', 'Action', '0', 'FIFA 23 is a football video game published by EA Sports. It is the 30th installment in the FIFA series that is developed by EA Sports, the final installment under the FIFA banner, and released worldwide on 30 September 2022 for Nintendo Switch, PlayStation 4, PlayStation 5, Windows, Xbox One and Xbox Series X/S.[2]  Kylian Mbappé and Sam Kerr are the cover athletes for the standard and legacy editions.  Listed in Guinness World Records as the best-selling sports video game franchise in the world, the game is the final under the 29-year partnership between EA and FIFA. Future football games by EA are named under the banner of EA Sports FC (alternatively just \"EASFC\", \"EAFC\" or \"FC\").[3]', 'Minimum requirements to run FIFA 23:  Processor (CPU): Intel Core i5 6600k or AMD Ryzen 5 1600 Memory (RAM): 8 GB Graphics (GPU): NVIDIA GeForce GTX 1050 Ti or AMD Radeon RX 570 DirectX: Version 12 Operating System (OS): Windows 10 64-bit Storage: 100 GB of available space Network: Broadband internet connection', 'Recommended requirements to run FIFA 23 for a better experience:  Processor (CPU): Intel Core i7 6700 or AMD Ryzen 7 2700X Memory (RAM): 12 GB Graphics (GPU): NVIDIA GeForce GTX 1660 or AMD Radeon RX 5600 XT DirectX: Version 12 Operating System (OS): Windows 10 64-bit Storage: 100 GB of available space Network: Broadband internet connection', NULL),
(83, 'Need For Speed Heat', 'img/nfs heat.jpg', 'Fighting', '0', 'Need for Speed Heat (stylised as NFS Heat) is a 2019 racing video game developed by Ghost Games and published by Electronic Arts for PlayStation 4, Windows, and Xbox One. It is the twenty-fourth installment in the Need for Speed series and commemorates the series\' 25th anniversary. The game received mixed reviews from critics, who mostly found the game to be an improvement over the 2015 Need for Speed reboot and Payback but not enough to be a full return to form for the franchise.  Heat was Ghost Games\' final game both for the Need for Speed franchise and as a lead developer. In February 2020, EA shifted development of the franchise back to Criterion Games—the developers of the Burnout series,', 'Minimum requirements to run Need for Speed Heat:  OS: Windows 10 Processor (AMD): FX-6350 or equivalent Processor (Intel): Core i5-3570 or equivalent Memory: 8 GB RAM Graphics Card (AMD): Radeon 7970/Radeon R9 280x or equivalent Graphics Card (Nvidia): GeForce GTX 760 or equivalent Direct X: 11 Online Connection Requirements: 320 KBPS Hard Drive Space: 50 GB', 'Recommended requirements to run Need for Speed Heat:  OS: Windows 10 Processor (AMD): Ryzen 3 1300X or equivalent Processor (Intel): Core i7-4790 or equivalent Memory: 16 GB RAM Graphics Card (AMD): Radeon RX 480 or equivalent Graphics Card (Nvidia): GeForce GTX 1060 or equivalent Direct X: 11 Online Connection Requirements: 512 KBPS Hard Drive Space: 50 GB', NULL),
(84, 'WWE 2k22', 'img/wwe.png', 'Fighting', '4000', 'WWE 2K22 is a 2022 professional wrestling sports video game developed by Visual Concepts and published by 2K. It is the twenty-second overall installment of the video game series based on WWE, the eighth game under the WWE 2K banner,[1][2][3] and the successor to 2019\'s WWE 2K20. [4] It was released on March 11, 2022, for PlayStation 4, PlayStation 5, Windows, Xbox One, and Xbox Series X/S.[5] The follow-up title, WWE 2K23, was released on March 14, 2023.', 'Minimum requirements to run WWE 2K22:  OS: Windows 10 64-bit Processor: Intel Core i5-3550 / AMD FX 8150 (AVX Compatible processor) Memory: 8 GB RAM Graphics: GeForce GTX 1060 / Radeon RX 480 (3GB of VRAM) DirectX: Version 12 Storage: 60 GB available space Sound Card: DirectX 9.0c compatible sound card', 'Recommended requirements to run WWE 2K22 with better performance and higher graphical settings:  OS: Windows 10 64-bit Processor: Intel Core i7-4790 / AMD FX 8350 (AVX Compatible processor) Memory: 16 GB RAM Graphics: GeForce GTX 1070 / Radeon RX 580 (6GB of VRAM) DirectX: Version 12 Storage: 60 GB available space Sound Card: DirectX 9.0c compatible sound card', NULL),
(96, 'NFS Most Wanted', 'img/nfs most.jpg', 'Racing', '0', 'The open-world action in Need for Speed Most Wanted gives you the freedom to drive your way. Hit jumps and shortcuts, switch cars, lie low, or head for terrain that plays to your vehicle’s unique strengths. Fight your way past cops and rivals using skill, high-end car tech, and tons of nitrous. It’s all about you, your friends, and a wild selection of cars. Let’s see what you can do.', 'OS:Windows Vista (Service Pack 2 and all available windows updates) 32-bit Processor:2 GHz Dual Core (Core 2 Duo 2.4 GHZ or Althon X2 2.7 GHz) Memory:2 GB Hard Drive:20 GB Graphics Card (AMD):DirectX 10.1 compatible with 512 MB RAM (ATI RADEON 3000, 4000, 5000 OR 6000 series, with ATI RADEON 3870 or higher performance) Graphics Card (NVIDIA):DirectX 10.0 compatible with 512 MB RAM (NVIDIA GEFORCE 8, 9, 200, 300, 400 OR 500 series with NVIDIA GEFORCE 8800 GT or higher performance) Sound card:DirectX compatible Keyboard and Mouse', 'OS:Windows 7 (Service Pack 1 and all available windows updates) 64-bit Processor:Quad-Core CPU Memory:4 GB Hard Drive:20 GB Graphics Card:DirectX 11 compatible with 1024 MB RAM (NVIDIA GEFORCE GTX 560 or ATI RADEON 6950) Sound Card:DirectX compatible Keyboard and Mouse', 1);

-- --------------------------------------------------------

--
-- Table structure for table `game_genres`
--

CREATE TABLE `game_genres` (
  `id` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `game_genres`
--

INSERT INTO `game_genres` (`id`, `genre`) VALUES
(13, 'Action'),
(29, 'Adventure'),
(3, 'Battle Royale'),
(5, 'Fighting'),
(15, 'Firing'),
(8, 'Open World'),
(28, 'Racing');

-- --------------------------------------------------------

--
-- Table structure for table `game_offer`
--

CREATE TABLE `game_offer` (
  `offer_id` int(255) NOT NULL,
  `game_offer_name` varchar(255) NOT NULL,
  `game_offer_img` varchar(255) NOT NULL,
  `game_actual_price` int(255) NOT NULL,
  `game_offer_price` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `game_offer`
--

INSERT INTO `game_offer` (`offer_id`, `game_offer_name`, `game_offer_img`, `game_actual_price`, `game_offer_price`) VALUES
(1, 'GTA 6', 'img/gta 6.jpg', 4000, 2500),
(2, 'RDR 2', 'img/rdr 2.jpg', 2500, 1200),
(3, 'Batte Field 5', 'img/bfield 5.jpg', 3400, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `help`
--

CREATE TABLE `help` (
  `person_id` int(50) NOT NULL,
  `person_name` varchar(50) NOT NULL,
  `person_email` varchar(50) NOT NULL,
  `person_msg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `help`
--

INSERT INTO `help` (`person_id`, `person_name`, `person_email`, `person_msg`) VALUES
(1, 'Mohsin', 'mohsin@gmail.com', 'Hello World , How are you ?'),
(2, 'Faraz', 'faraz@gmail.com', 'Hi everyone how are you ?'),
(3, 'Mark', 'mark@gmail.com', 'Hey iam mark zukerburger'),
(4, 'Ahmed', 'ahmed@gmail.com', 'Lorem ipsum dolor sit amet, consectetur adipisicin'),
(5, 'Ahmed ali', 'ahmed@gmail.com', 'Hi everyone how are you');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `email`, `password`) VALUES
(24, 'mohsin786', 'panhwermohsinali@gmail.com', '0d9e90566e81686467710cde1e09831c'),
(25, 'zain', 'musickingdom124@gmail.com', 'df6b652e7a56c4f52bc394fe40d639b2'),
(26, 'ahsan', 'daniyal@gmail.com', '624051640aef5235506cb3726fb215b1'),
(27, 'asim', 'asim@gmail.com', 'asim786'),
(28, 'Mohsin', 'mohsin@gmail.com', 'mohsin86');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `game_genres`
--
ALTER TABLE `game_genres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `genre` (`genre`);

--
-- Indexes for table `game_offer`
--
ALTER TABLE `game_offer`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`person_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `game_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `game_genres`
--
ALTER TABLE `game_genres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `game_offer`
--
ALTER TABLE `game_offer`
  MODIFY `offer_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `help`
--
ALTER TABLE `help`
  MODIFY `person_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
